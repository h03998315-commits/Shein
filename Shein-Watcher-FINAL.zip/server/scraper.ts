
import { chromium } from "playwright";

export async function scrapeShein() {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto("https://www.sheinindia.in");
  console.log("Scraped page");
  await browser.close();
}
