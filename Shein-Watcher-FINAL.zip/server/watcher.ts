
import { scrapeShein } from "./scraper.js";

let running = false;

export async function startWatcher() {
  if (running) return;
  running = true;
  console.log("Watcher started");
  setInterval(scrapeShein, 8 * 60 * 1000);
}

export function stopWatcher() {
  running = false;
  console.log("Watcher stopped");
}
