
import fetch from "node-fetch";
import { startWatcher, stopWatcher } from "./watcher.js";

export function startTelegramBot() {
  const token = process.env.BOT_TOKEN;
  if (!token) return;
  console.log("Telegram bot started");
}
