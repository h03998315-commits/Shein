
import express from "express";
import { startTelegramBot } from "./telegram.js";
import { startWatcher } from "./watcher.js";

const app = express();
app.use(express.json());

app.get("/health", (_, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log("Server running on", PORT);
  startTelegramBot();
  startWatcher();
});
