
# Shein Watcher – Final Version

A full Shein product watcher with:
- Playwright anti-block scraping
- Express + TypeScript backend
- PostgreSQL (Drizzle ORM)
- Telegram Bot Admin Panel
- Web Admin Dashboard (React)

## Quick Start

1. Install deps:
   npm install

2. Setup env:
   cp .env.example .env

3. Run DB:
   npm run db:push

4. Start:
   npm run dev

Telegram bot commands:
/startwatcher
/stopwatcher
/forcecheck
/status
/set WATCH_URL <url>
