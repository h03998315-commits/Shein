
import { pgTable, text, serial, timestamp, boolean, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Store detected products (previously state.json)
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  goodsId: varchar("goods_id").notNull().unique(), // The Shein Goods ID
  detectedAt: timestamp("detected_at").defaultNow(),
  // Extra fields we might want to capture later
  name: text("name"),
  price: text("price"),
  imageUrl: text("image_url"),
});

// Store configuration (env vars replacement)
export const settings = pgTable("settings", {
  key: varchar("key").primaryKey(), // e.g., 'WATCH_URL', 'BOT_TOKEN'
  value: text("value").notNull(),
});

// Store proxies
export const proxies = pgTable("proxies", {
  id: serial("id").primaryKey(),
  address: text("address").notNull().unique(), // ip:port or user:pass@ip:port
  lastUsedAt: timestamp("last_used_at"),
  isWorking: boolean("is_working").default(true),
});

// === SCHEMAS ===
export const insertProductSchema = createInsertSchema(products).omit({ id: true, detectedAt: true });
export const insertSettingSchema = createInsertSchema(settings);
export const insertProxySchema = createInsertSchema(proxies).omit({ id: true, lastUsedAt: true, isWorking: true });

// === TYPES ===
export type Product = typeof products.$inferSelect;
export type Setting = typeof settings.$inferSelect;
export type Proxy = typeof proxies.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type InsertProxy = z.infer<typeof insertProxySchema>;

// === API REQUEST/RESPONSE TYPES ===
export type WatcherStatus = {
  isRunning: boolean;
  lastCheck: string | null; // ISO date string
  productCount: number;
  proxyCount: number;
};
