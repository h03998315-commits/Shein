
import { z } from 'zod';
import { insertProductSchema, insertSettingSchema, insertProxySchema, products, settings, proxies } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  products: {
    list: {
      method: 'GET' as const,
      path: '/api/products',
      input: z.object({
        limit: z.coerce.number().optional(),
        offset: z.coerce.number().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof products.$inferSelect>()),
      },
    },
  },
  settings: {
    list: {
      method: 'GET' as const,
      path: '/api/settings',
      responses: {
        200: z.array(z.custom<typeof settings.$inferSelect>()),
      },
    },
    update: {
      method: 'POST' as const,
      path: '/api/settings',
      input: z.object({
        settings: z.array(insertSettingSchema),
      }),
      responses: {
        200: z.array(z.custom<typeof settings.$inferSelect>()),
      },
    },
  },
  proxies: {
    list: {
      method: 'GET' as const,
      path: '/api/proxies',
      responses: {
        200: z.array(z.custom<typeof proxies.$inferSelect>()),
      },
    },
    upload: {
      method: 'POST' as const,
      path: '/api/proxies/upload',
      input: z.object({
        proxies: z.string(), // Raw text content
      }),
      responses: {
        200: z.object({ count: z.number() }),
      },
    },
    clear: {
      method: 'DELETE' as const,
      path: '/api/proxies',
      responses: {
        200: z.void(),
      },
    },
  },
  watcher: {
    status: {
      method: 'GET' as const,
      path: '/api/watcher/status',
      responses: {
        200: z.object({
          isRunning: z.boolean(),
          lastCheck: z.string().nullable(),
          productCount: z.number(),
          proxyCount: z.number(),
        }),
      },
    },
    start: {
      method: 'POST' as const,
      path: '/api/watcher/start',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
    stop: {
      method: 'POST' as const,
      path: '/api/watcher/stop',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
    force: {
      method: 'POST' as const,
      path: '/api/watcher/force',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
