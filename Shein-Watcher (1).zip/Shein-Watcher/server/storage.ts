
import { db } from "./db";
import {
  products, settings, proxies,
  type Product, type InsertProduct,
  type Setting, type InsertSetting,
  type Proxy, type InsertProxy
} from "@shared/schema";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Products
  getProducts(limit?: number, offset?: number): Promise<Product[]>;
  getProductByGoodsId(goodsId: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  getProductCount(): Promise<number>;

  // Settings
  getSettings(): Promise<Setting[]>;
  getSetting(key: string): Promise<string | undefined>;
  updateSetting(key: string, value: string): Promise<Setting>;

  // Proxies
  getProxies(): Promise<Proxy[]>;
  getWorkingProxies(): Promise<Proxy[]>;
  addProxies(proxiesList: InsertProxy[]): Promise<void>;
  clearProxies(): Promise<void>;
  getProxyCount(): Promise<number>;
  markProxyStatus(id: number, isWorking: boolean): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(limit = 100, offset = 0): Promise<Product[]> {
    return await db.select()
      .from(products)
      .orderBy(desc(products.detectedAt))
      .limit(limit)
      .offset(offset);
  }

  async getProductByGoodsId(goodsId: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.goodsId, goodsId));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).onConflictDoNothing().returning();
    // In case of conflict (already exists), return the existing one
    if (!newProduct) {
        return (await this.getProductByGoodsId(product.goodsId))!;
    }
    return newProduct;
  }

  async getProductCount(): Promise<number> {
    const [result] = await db.select({ count: sql<number>`count(*)` }).from(products);
    return Number(result.count);
  }

  async getSettings(): Promise<Setting[]> {
    return await db.select().from(settings);
  }

  async getSetting(key: string): Promise<string | undefined> {
    const [setting] = await db.select().from(settings).where(eq(settings.key, key));
    return setting?.value;
  }

  async updateSetting(key: string, value: string): Promise<Setting> {
    const [updated] = await db.insert(settings)
      .values({ key, value })
      .onConflictDoUpdate({ target: settings.key, set: { value } })
      .returning();
    return updated;
  }

  async getProxies(): Promise<Proxy[]> {
    return await db.select().from(proxies).limit(1000); // Limit for UI performance
  }

  async getWorkingProxies(): Promise<Proxy[]> {
    return await db.select().from(proxies).where(eq(proxies.isWorking, true));
  }

  async addProxies(proxiesList: InsertProxy[]): Promise<void> {
    if (proxiesList.length === 0) return;
    // Batch insert
    // Drizzle batch insert handling
    const batchSize = 1000;
    for (let i = 0; i < proxiesList.length; i += batchSize) {
        const batch = proxiesList.slice(i, i + batchSize);
        await db.insert(proxies).values(batch).onConflictDoNothing();
    }
  }

  async clearProxies(): Promise<void> {
    await db.delete(proxies);
  }

  async getProxyCount(): Promise<number> {
    const [result] = await db.select({ count: sql<number>`count(*)` }).from(proxies);
    return Number(result.count);
  }

  async markProxyStatus(id: number, isWorking: boolean): Promise<void> {
    await db.update(proxies).set({ isWorking, lastUsedAt: new Date() }).where(eq(proxies.id, id));
  }
}

export const storage = new DatabaseStorage();
