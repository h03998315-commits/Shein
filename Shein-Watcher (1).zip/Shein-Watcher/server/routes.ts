
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { getWatcherStatus, startWatcher, stopWatcher, forceCheck } from "./services/watcher";
import { z } from "zod";
import fs from "fs";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Products
  app.get(api.products.list.path, async (req, res) => {
    const limit = Number(req.query.limit) || 100;
    const offset = Number(req.query.offset) || 0;
    const products = await storage.getProducts(limit, offset);
    res.json(products);
  });

  // Settings
  app.get(api.settings.list.path, async (req, res) => {
    const settings = await storage.getSettings();
    res.json(settings);
  });

  app.post(api.settings.update.path, async (req, res) => {
    const { settings } = req.body;
    const updated = [];
    for (const s of settings) {
      updated.push(await storage.updateSetting(s.key, s.value));
    }
    // Also try to start watcher if all settings are present?
    res.json(updated);
  });

  // Proxies
  app.get(api.proxies.list.path, async (req, res) => {
    const proxies = await storage.getProxies();
    res.json(proxies);
  });

  app.post(api.proxies.upload.path, async (req, res) => {
    const { proxies } = req.body;
    const lines = proxies.split("\n").map(l => l.trim()).filter(Boolean);
    const validProxies = lines.map(address => ({ address }));
    
    await storage.addProxies(validProxies);
    res.json({ count: validProxies.length });
  });

  app.delete(api.proxies.clear.path, async (req, res) => {
    await storage.clearProxies();
    res.json({});
  });

  // Watcher
  app.get(api.watcher.status.path, async (req, res) => {
    const status = getWatcherStatus();
    const productCount = await storage.getProductCount();
    const proxyCount = await storage.getProxyCount();
    res.json({ ...status, productCount, proxyCount });
  });

  app.post(api.watcher.start.path, async (req, res) => {
    await startWatcher();
    res.json({ message: "Watcher started" });
  });

  app.post(api.watcher.stop.path, async (req, res) => {
    stopWatcher();
    res.json({ message: "Watcher stopped" });
  });

  app.post(api.watcher.force.path, async (req, res) => {
    // Run in background, don't await
    forceCheck(); 
    res.json({ message: "Force check initiated" });
  });

  // Seed initial proxies if needed
  seedProxies();

  return httpServer;
}

async function seedProxies() {
  const count = await storage.getProxyCount();
  // We want to upload ALL proxies if asked or if count is low
  // The user asked to upload ALL proxies, so we should bypass the count check if we want to be sure.
  // But to avoid infinite loops on every restart, let's just increase the limit if it was already seeded with only 1000.
  if (count > 5000) return; 
  
  const proxyFile = "attached_assets/http_proxies_1767803197239.txt";
  if (fs.existsSync(proxyFile)) {
    console.log("Seeding all proxies from attached file...");
    const data = fs.readFileSync(proxyFile, "utf-8");
    const lines = data.split("\n").map(l => l.trim()).filter(Boolean);
    const proxyObjects = lines.map(address => ({ address }));
    await storage.addProxies(proxyObjects);
    console.log(`Seeded ${proxyObjects.length} proxies.`);
  }
}
