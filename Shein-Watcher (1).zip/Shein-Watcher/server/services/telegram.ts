
import { storage } from "../storage";
import fetch from "node-fetch";

export async function notifyAdmins(text: string) {
  const token = await storage.getSetting("BOT_TOKEN");
  const adminIdsStr = await storage.getSetting("ADMIN_IDS");

  if (!token || !adminIdsStr) {
    console.log("Telegram not configured, skipping notification:", text);
    return;
  }

  const adminIds = adminIdsStr.split(",").map(id => id.trim()).filter(Boolean);
  const API = `https://api.telegram.org/bot${token}`;

  for (const id of adminIds) {
    try {
      await fetch(`${API}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: id, text })
      });
    } catch (e) {
      console.error(`Failed to send telegram message to ${id}:`, e);
    }
  }
}
