
import { createContext, fetchHTML, parseProducts } from "./scraper";
import { storage } from "../storage";
import { notifyAdmins } from "./telegram";
import { InsertProduct } from "@shared/schema";

let running = false;
let lastCheck: Date | null = null;
let watcherInterval: NodeJS.Timeout | null = null;

const CHECK_INTERVAL = 8 * 60 * 1000; // 8 minutes

export function getWatcherStatus() {
  return {
    isRunning: running,
    lastCheck: lastCheck ? lastCheck.toISOString() : null
  };
}

export async function startWatcher() {
  if (running) return;
  running = true;
  console.log("Watcher started");
  
  // Run immediately then interval
  runCheck();
  watcherInterval = setInterval(runCheck, CHECK_INTERVAL);
}

export function stopWatcher() {
  running = false;
  if (watcherInterval) {
    clearInterval(watcherInterval);
    watcherInterval = null;
  }
  console.log("Watcher stopped");
}

export async function forceCheck() {
  console.log("Force check initiated");
  await runCheck();
}

async function runCheck() {
  if (!running && !watcherInterval) {
      // Allow forceCheck to run even if stopped, but safeguard against zombie loops
      // If called via forceCheck, we just run.
  }

  try {
    lastCheck = new Date();
    const url = await storage.getSetting("WATCH_URL");
    if (!url) {
      console.log("No WATCH_URL configured");
      return;
    }

    const { browser, context, proxyId } = await createContext();
    
    try {
      const html = await fetchHTML(context, url);
      const productIds = parseProducts(html);
      console.log(`Found ${productIds.size} products`);

      // We need to diff against what we already have. 
      // However, for simplicity and database scale, we just try to insert all.
      // createProduct handles duplication gracefully.
      // But we only want to notify on NEW ones.

      for (const id of productIds) {
        const existing = await storage.getProductByGoodsId(id);
        if (!existing) {
          await storage.createProduct({ goodsId: id });
          await notifyAdmins(`🆕 New product live: ${id}`);
          console.log(`New product found: ${id}`);
        }
      }

      // If successful and using a proxy, mark it working? 
      // We assume it's working if we got here.
      if (proxyId) {
          // await storage.markProxyStatus(proxyId, true);
      }

    } catch (e) {
      console.error("Scraping error:", e);
      if (proxyId) {
        await storage.markProxyStatus(proxyId, false); // Mark proxy as bad on error? Or just log.
      }
    } finally {
      await browser.close();
    }

  } catch (e) {
    console.error("Watcher loop error:", e);
  }
}
