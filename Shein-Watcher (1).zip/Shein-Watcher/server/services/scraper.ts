
import { chromium, type Browser, type BrowserContext } from "playwright";
import { storage } from "../storage";

// Helper for sleep
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

async function getRandomProxy() {
  const proxies = await storage.getWorkingProxies();
  if (proxies.length === 0) return undefined;
  const proxy = proxies[Math.floor(Math.random() * proxies.length)];
  return proxy;
}

export async function createContext() {
  const proxy = await getRandomProxy();
  
  const launchOptions: any = {
    headless: true,
    args: ["--disable-blink-features=AutomationControlled", "--no-sandbox"]
  };

  if (proxy) {
    launchOptions.proxy = { server: `http://${proxy.address}` };
  }

  console.log(`Launching browser with proxy: ${proxy ? proxy.address : 'DIRECT'}`);

  const browser = await chromium.launch(launchOptions);

  const context = await browser.newContext({
    userAgent: "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile",
    locale: "en-IN",
    timezoneId: "Asia/Kolkata"
  });
  
  return { browser, context, proxyId: proxy?.id };
}

export async function fetchHTML(ctx: BrowserContext, url: string) {
  const page = await ctx.newPage();

  try {
    await page.route("**/*", route => {
      const t = route.request().resourceType();
      if (["image", "font", "media"].includes(t)) route.abort();
      else route.continue();
    });

    await page.goto(url, { timeout: 60000, waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(4000); // Wait for dynamic content

    const html = await page.content();
    await page.close();
    return html;
  } catch (e) {
    await page.close();
    throw e;
  }
}

export function parseProducts(html: string): Set<string> {
  const set = new Set<string>();
  const regex = /"goods_id":"(\d+)"/g;
  let m;
  while ((m = regex.exec(html))) set.add(m[1]);
  return set;
}
