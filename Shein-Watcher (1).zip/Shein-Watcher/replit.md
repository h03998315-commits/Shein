# Shein Product Watcher

## Overview

This is a full-stack web application that monitors Shein product pages for new product listings. It uses Playwright for web scraping, supports proxy rotation for avoiding rate limits, and sends Telegram notifications when new products are detected. The dashboard provides real-time status monitoring, product history, proxy management, and configuration settings.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter (lightweight alternative to React Router)
- **State Management**: TanStack React Query for server state
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Animations**: Framer Motion for page transitions
- **Build Tool**: Vite with path aliases (@/ for client/src, @shared for shared)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Design**: RESTful endpoints defined in shared/routes.ts with Zod validation
- **Web Scraping**: Playwright with Chromium for headless browser automation
- **Background Processing**: Interval-based watcher service that checks every 8 minutes

### Data Storage
- **Database**: PostgreSQL via Drizzle ORM
- **Schema**: Three main tables - products (detected items), settings (configuration), proxies (rotation pool)
- **Migrations**: Drizzle Kit with push command (db:push)

### Key Services
- **Watcher Service** (server/services/watcher.ts): Orchestrates periodic scraping, manages start/stop state
- **Scraper Service** (server/services/scraper.ts): Handles Playwright browser automation with proxy support
- **Telegram Service** (server/services/telegram.ts): Sends notifications to configured admin IDs

### API Structure
All endpoints prefixed with /api:
- Products: GET /api/products (list detected products)
- Settings: GET/POST /api/settings (configuration management)
- Proxies: GET/POST/DELETE /api/proxies (proxy pool management)
- Watcher: GET status, POST start/stop/force (control scraping service)

### Build System
- Development: tsx for TypeScript execution with Vite dev server
- Production: esbuild bundles server, Vite builds client to dist/public
- Server bundles specific dependencies (listed in script/build.ts allowlist) to reduce cold start times

## External Dependencies

### Database
- **PostgreSQL**: Required, connection via DATABASE_URL environment variable
- **Drizzle ORM**: Schema defined in shared/schema.ts, migrations in /migrations

### Third-Party Services
- **Telegram Bot API**: For sending notifications (requires BOT_TOKEN and ADMIN_IDS settings)
- **HTTP Proxies**: Optional proxy list for rotating IP addresses during scraping (stored in database)

### Browser Automation
- **Playwright**: Uses Chromium for headless scraping with anti-detection measures
- Configured with mobile user agent and India locale for Shein access

### Key NPM Packages
- drizzle-orm, drizzle-zod: Database ORM and validation
- playwright: Browser automation
- express, express-session: HTTP server
- @tanstack/react-query: Client-side data fetching
- zod: Schema validation across client and server