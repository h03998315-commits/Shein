## Packages
date-fns | Date formatting for detected products and logs
framer-motion | Smooth transitions for dashboard elements and page navigations
recharts | Visualization for product detection trends (optional but recommended for dashboards)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
  mono: ["var(--font-mono)"],
}
