import { PageLayout } from "@/components/layout/PageLayout";
import { useSettings, useUpdateSettings } from "@/hooks/use-settings";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useForm } from "react-hook-form";
import { useEffect } from "react";
import { Save } from "lucide-react";

type FormData = {
  WATCH_URL: string;
  BOT_TOKEN: string;
  ADMIN_IDS: string;
};

export default function Settings() {
  const { data: settings, isLoading } = useSettings();
  const updateSettings = useUpdateSettings();

  const { register, handleSubmit, setValue, reset } = useForm<FormData>();

  useEffect(() => {
    if (settings) {
      settings.forEach((s) => {
        if (s.key === "WATCH_URL") setValue("WATCH_URL", s.value);
        if (s.key === "BOT_TOKEN") setValue("BOT_TOKEN", s.value);
        if (s.key === "ADMIN_IDS") setValue("ADMIN_IDS", s.value);
      });
    }
  }, [settings, setValue]);

  const onSubmit = (data: FormData) => {
    updateSettings.mutate({
      settings: [
        { key: "WATCH_URL", value: data.WATCH_URL },
        { key: "BOT_TOKEN", value: data.BOT_TOKEN },
        { key: "ADMIN_IDS", value: data.ADMIN_IDS },
      ],
    });
  };

  if (isLoading) {
    return (
      <PageLayout title="Configuration">
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-48 mb-2" />
            <Skeleton className="h-4 w-64" />
          </CardHeader>
          <CardContent className="space-y-6">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </PageLayout>
    );
  }

  return (
    <PageLayout title="Configuration">
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card className="max-w-3xl">
          <CardHeader>
            <CardTitle>Watcher Settings</CardTitle>
            <CardDescription>
              Configure the target URL and Telegram notifications.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="WATCH_URL">Watch URL</Label>
              <Input
                id="WATCH_URL"
                {...register("WATCH_URL", { required: true })}
                placeholder="https://www.sheinindia.in/c/..."
                className="font-mono text-sm"
              />
              <p className="text-xs text-muted-foreground">The Shein category URL to monitor.</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="BOT_TOKEN">Telegram Bot Token</Label>
              <Input
                id="BOT_TOKEN"
                type="password"
                {...register("BOT_TOKEN", { required: true })}
                placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
                className="font-mono text-sm"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ADMIN_IDS">Admin IDs</Label>
              <Input
                id="ADMIN_IDS"
                {...register("ADMIN_IDS", { required: true })}
                placeholder="123456789, 987654321"
                className="font-mono text-sm"
              />
              <p className="text-xs text-muted-foreground">
                Comma-separated list of Telegram User IDs to notify.
              </p>
            </div>

            <div className="pt-4 flex justify-end">
              <Button
                type="submit"
                className="px-8 font-semibold shadow-lg shadow-primary/20"
                disabled={updateSettings.isPending}
              >
                {updateSettings.isPending ? (
                  "Saving..."
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" /> Save Changes
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </PageLayout>
  );
}
