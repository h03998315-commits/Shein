import { PageLayout } from "@/components/layout/PageLayout";
import { StatusCard } from "@/components/StatusCard";
import { StatCard } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import { useWatcherStatus, useWatcherActions } from "@/hooks/use-watcher";
import { Play, Square, RefreshCw, ShoppingBag, ShieldCheck } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: status, isLoading } = useWatcherStatus();
  const { start, stop, forceCheck } = useWatcherActions();

  if (isLoading) {
    return (
      <PageLayout title="Dashboard">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Skeleton className="h-40 rounded-2xl" />
          <Skeleton className="h-40 rounded-2xl" />
          <Skeleton className="h-40 rounded-2xl" />
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout
      title="Dashboard"
      actions={
        <Button
          variant="outline"
          size="sm"
          onClick={() => forceCheck.mutate()}
          disabled={forceCheck.isPending}
          className="gap-2"
        >
          <RefreshCw className={`w-4 h-4 ${forceCheck.isPending ? "animate-spin" : ""}`} />
          Force Check
        </Button>
      }
    >
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Status Card */}
        <div className="lg:col-span-1">
          <StatusCard
            isRunning={status?.isRunning ?? false}
            lastCheck={status?.lastCheck ?? null}
          />
          <div className="mt-4 grid grid-cols-2 gap-3">
            <Button
              className="w-full gap-2 shadow-lg shadow-green-500/20"
              variant={status?.isRunning ? "secondary" : "default"}
              disabled={status?.isRunning || start.isPending}
              onClick={() => start.mutate()}
            >
              <Play className="w-4 h-4" /> Start
            </Button>
            <Button
              className="w-full gap-2"
              variant={status?.isRunning ? "destructive" : "secondary"}
              disabled={!status?.isRunning || stop.isPending}
              onClick={() => stop.mutate()}
            >
              <Square className="w-4 h-4 fill-current" /> Stop
            </Button>
          </div>
        </div>

        {/* Stats */}
        <StatCard
          title="Total Detected"
          value={status?.productCount ?? 0}
          icon={ShoppingBag}
          className="bg-gradient-to-br from-card to-secondary/30"
        />
        <StatCard
          title="Active Proxies"
          value={status?.proxyCount ?? 0}
          icon={ShieldCheck}
          className="bg-gradient-to-br from-card to-secondary/30"
        />
      </div>

      {/* Recent Activity Hint */}
      <div className="mt-8 bg-primary/5 border border-primary/10 rounded-2xl p-6">
        <h3 className="font-display font-bold text-lg text-primary">System Notice</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          The watcher is configured to run every 8 minutes. Proxies are automatically rotated.
          Check the Products page for live updates.
        </p>
      </div>
    </PageLayout>
  );
}
