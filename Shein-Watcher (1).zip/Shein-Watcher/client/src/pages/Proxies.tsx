import { PageLayout } from "@/components/layout/PageLayout";
import { useProxies, useUploadProxies, useClearProxies } from "@/hooks/use-proxies";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { ShieldAlert, Upload, Trash2 } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Proxies() {
  const { data: proxies, isLoading } = useProxies();
  const uploadProxies = useUploadProxies();
  const clearProxies = useClearProxies();
  const { toast } = useToast();

  const [text, setText] = useState("");

  const handleUpload = () => {
    if (!text.trim()) {
      toast({ title: "Empty", description: "Please enter some proxies first.", variant: "destructive" });
      return;
    }
    uploadProxies.mutate(text, {
      onSuccess: () => setText(""),
    });
  };

  return (
    <PageLayout title="Proxy Management">
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Upload Section */}
        <Card className="h-full flex flex-col">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-primary" /> Import Proxies
            </CardTitle>
            <CardDescription>
              Paste your proxy list here. One per line.
              <br />
              Format: <code>ip:port</code> or <code>user:pass@ip:port</code>
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col gap-4">
            <Textarea
              className="flex-1 min-h-[300px] font-mono text-sm bg-muted/30 resize-none focus:bg-background transition-colors"
              placeholder="192.168.1.1:8080&#10;user:pass@10.0.0.1:3128"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            <Button
              className="w-full shadow-md"
              onClick={handleUpload}
              disabled={uploadProxies.isPending}
            >
              {uploadProxies.isPending ? "Uploading..." : "Upload Proxies"}
            </Button>
          </CardContent>
        </Card>

        {/* Status Section */}
        <div className="space-y-6">
          <Card className="border-l-4 border-l-primary">
            <CardHeader>
              <CardTitle>Proxy Status</CardTitle>
              <CardDescription>Current pool statistics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2">
                <span className="text-5xl font-display font-bold text-primary">
                  {isLoading ? "-" : proxies?.length}
                </span>
                <span className="text-muted-foreground mb-2 font-medium">active proxies</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-destructive/5 border-destructive/20">
            <CardHeader>
              <CardTitle className="text-destructive flex items-center gap-2">
                <ShieldAlert className="w-5 h-5" /> Danger Zone
              </CardTitle>
              <CardDescription>
                Irreversible actions for proxy management.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full" disabled={proxies?.length === 0}>
                    <Trash2 className="w-4 h-4 mr-2" /> Clear All Proxies
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will remove all proxies from the database. The watcher may fail if no proxies are available.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      onClick={() => clearProxies.mutate()}
                    >
                      Yes, clear all
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
}
