import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useProxies() {
  return useQuery({
    queryKey: [api.proxies.list.path],
    queryFn: async () => {
      const res = await fetch(api.proxies.list.path);
      if (!res.ok) throw new Error("Failed to fetch proxies");
      return api.proxies.list.responses[200].parse(await res.json());
    },
  });
}

export function useUploadProxies() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (content: string) => {
      const res = await fetch(api.proxies.upload.path, {
        method: api.proxies.upload.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ proxies: content }),
      });
      if (!res.ok) throw new Error("Failed to upload proxies");
      return api.proxies.upload.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.proxies.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.watcher.status.path] });
      toast({ title: "Success", description: `Uploaded ${data.count} proxies` });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}

export function useClearProxies() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.proxies.clear.path, {
        method: api.proxies.clear.method,
      });
      if (!res.ok) throw new Error("Failed to clear proxies");
      return;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.proxies.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.watcher.status.path] });
      toast({ title: "Success", description: "All proxies cleared" });
    },
  });
}
