import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useWatcherStatus() {
  return useQuery({
    queryKey: [api.watcher.status.path],
    queryFn: async () => {
      const res = await fetch(api.watcher.status.path);
      if (!res.ok) throw new Error("Failed to fetch watcher status");
      return api.watcher.status.responses[200].parse(await res.json());
    },
    refetchInterval: 5000, // Poll every 5 seconds
  });
}

export function useWatcherActions() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const startMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.watcher.start.path, { method: api.watcher.start.method });
      if (!res.ok) throw new Error("Failed to start watcher");
      return api.watcher.start.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.watcher.status.path] });
      toast({ title: "Watcher Started", description: data.message, variant: "default" });
    },
  });

  const stopMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.watcher.stop.path, { method: api.watcher.stop.method });
      if (!res.ok) throw new Error("Failed to stop watcher");
      return api.watcher.stop.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.watcher.status.path] });
      toast({ title: "Watcher Stopped", description: data.message, variant: "destructive" });
    },
  });

  const forceCheckMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.watcher.force.path, { method: api.watcher.force.method });
      if (!res.ok) throw new Error("Failed to force check");
      return api.watcher.force.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.watcher.status.path] });
      queryClient.invalidateQueries({ queryKey: [api.products.list.path] });
      toast({ title: "Check Initiated", description: data.message });
    },
  });

  return {
    start: startMutation,
    stop: stopMutation,
    forceCheck: forceCheckMutation,
  };
}
