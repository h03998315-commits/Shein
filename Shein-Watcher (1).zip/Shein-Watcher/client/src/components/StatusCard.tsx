import { cn } from "@/lib/utils";
import { Activity, PauseCircle } from "lucide-react";

interface StatusCardProps {
  isRunning: boolean;
  lastCheck: string | null;
}

export function StatusCard({ isRunning, lastCheck }: StatusCardProps) {
  const formattedDate = lastCheck
    ? new Date(lastCheck).toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "medium",
      })
    : "Never";

  return (
    <div className="relative overflow-hidden rounded-2xl border bg-card p-6 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">System Status</p>
          <div className="mt-2 flex items-center gap-2">
            <div
              className={cn(
                "h-2.5 w-2.5 rounded-full",
                isRunning ? "bg-green-500 animate-pulse" : "bg-red-500"
              )}
            />
            <h3 className="text-2xl font-bold font-display tracking-tight">
              {isRunning ? "Running" : "Stopped"}
            </h3>
          </div>
        </div>
        <div
          className={cn(
            "p-3 rounded-xl",
            isRunning ? "bg-green-500/10 text-green-600" : "bg-red-500/10 text-red-600"
          )}
        >
          {isRunning ? <Activity className="w-6 h-6" /> : <PauseCircle className="w-6 h-6" />}
        </div>
      </div>
      <div className="mt-6 flex items-center text-xs text-muted-foreground">
        <span className="font-mono">Last Check: {formattedDate}</span>
      </div>
      
      {/* Background decoration */}
      <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-gradient-to-br from-primary/5 to-primary/0 rounded-full blur-2xl pointer-events-none" />
    </div>
  );
}
